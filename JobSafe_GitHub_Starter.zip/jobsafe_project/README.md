# JobSafe — Fake Job Scam Detection and Risk Analysis System

**Student prototype for the proposed project:** Fake Job Scam Detection and Risk Analysis System using Machine Learning and Natural Language Processing.

## What is included
- `index.html`: a responsive browser-based demonstration.
- Paste a job advertisement and receive a demo risk score with explainable keyword warnings.
- Sample suspicious job text for testing.

## How to run
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Paste a job listing and select **Analyze risk**.

## Current scope and limitations
This repository contains an early **rule-based demonstration**, not a trained machine-learning/NLP model. Scores are illustrative keyword-rule scores, not calibrated fraud probabilities. The demo does not verify company registration, fetch URLs, or analyze screenshots. Do not treat a low score as proof that a job is genuine.

## Proposed future work
- Evaluate a labeled dataset of genuine and fraudulent job posts.
- Develop and validate an ML text classifier and report precision, recall, F1-score, and confusion matrix.
- Add URL and image/OCR analysis only if feasible and evaluated.
- Improve explanations and add safe reporting guidance.

## Safety note
Never pay a fee to obtain a job or share OTPs, passwords, PINs, or banking credentials with a recruiter.
